{
	"email": "PLACE EMAIL HERE", 
	"invokedby": "arn:PARTITION:lambda:REGION:ACCOUNT:function:ASA-IAM-Access-Key-Rotation-Function",
	"subject": "[IMPORTANT] Active AWS IAM Access Key was Rotated to Inactive due to Key Age Security Violation.",
	"email_template": "iam-auto-key-rotation-enforcement.html",
    "template_values": {
        "account_id": "PLACE ACCOUNT ID HERE", 
        "account_name": "ACCOUNT NAME",
        "timestamp": "2021-11-04T22:48:39.640450+00:00", 
        "actions": ["ACTION: ROTATE key username-here:key-arn-here.  Forced active key rotation."],
        "rotation_period": 90, 
        "installation_grace_period": 7, 
        "recovery_grace_period": 10, 
        "partition_name": "AWS Standard"
        }
}