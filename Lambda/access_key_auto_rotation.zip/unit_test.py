# Force Key Rotation Test for Lambda Test Event
{
  "ForceRotate": "USERNAME",
  "account": "AWS ACCOUNT ID",
  "name": "ACCOUNT NAME",
  "email": "EMAIL ADDRESS"
}

# Regular Test for Lambda Test Event
{
  "account": "AWS ACCOUNT ID",
  "name": "ACCOUNT NAME",
  "email": "EMAIL ADDRESS"
}
